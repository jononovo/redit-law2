# SecureFill (v3)

A Chrome extension (Manifest V3) that fills form fields **from a referenced
source**, keeping the values out of the calling assistant's context.

An AI assistant driving a browser asks SecureFill to fill fields by passing a
single opaque **reference**. The extension resolves the real values itself,
fills them into the page — including inside cross-origin iframes — and returns
only a **status**. The values never enter the assistant's reasoning, logs, or
tool calls.

It is **value-type agnostic**: a referenced source can hold a login, an API
token, a shipping address, a phone number, payment details — anything that
should stay out of the model context. Payment data is just one (initial) case.

## How it works

```
assistant (page main world)          SecureFill (isolated world + worker)
  │  postMessage {securefill-fill,ref}     │  content.js (top frame)
  │                                         │  └─► service worker
  │                                         │       ├─ fetch one-time key by ref
  │                                         │       ├─ AES-256-GCM decrypt source
  │                                         │       ├─ map each field → its frame
  │                                         │       └─ fill via per-frame scripts
  │  ◄── {status:"filled", …} ──────────────┤
```

The assistant runs in the page's main world. SecureFill's content scripts run in
an isolated world the page cannot read, and resolution/decryption happen in the
service worker. That boundary keeps values out of context.

### Two message namespaces (drop-in compatible)
The top-frame bridge accepts **both** `creditclaw-*` (what the CreditClaw
`secure-checkout` skill posts) and `securefill-*` (neutral). They are treated
identically, so this works with the existing skill and as a general tool.

| Message | Payload | Result |
|---|---|---|
| `…-ping` | — | `…-pong { ready, configured, version }` |
| `…-status` | — | `…-status-result { configured, profile, version }` |
| `…-schema` | — | `…-schema-result { profile, tokens }` (names only, no decrypt) |
| `…-fill` | `{ ref }` or `{ checkout_id, fields?, targets? }` | `…-fill-result { status, fields_filled, … }` + `window.__creditclawFillResult` |

`setup` / `clear` are **not** accepted from the page — only from the extension's
own options page. A page cannot set or wipe stored credentials.

## Resolution & crypto (matches the CreditClaw wire format)

- The stored source is `base64( ciphertext ‖ 16-byte GCM tag )` — the tag is
  inline (standard WebCrypto output). Paste it with or without the
  `ENCRYPTED_CARD_START/END` markers; the setup page strips them.
- `POST /bot/rail5/key { checkout_id }` returns `key_hex` (32-byte key) and
  `iv_hex` (12-byte IV) as lowercase hex. (`tag_hex` is also returned but is the
  same bytes already inline, so the WebCrypto path ignores it.)
- Decrypt = base64-decode the source, import the key, `subtle.decrypt` with the
  IV. Plaintext JSON: `{ number, cvv, exp_month, exp_year, name, address?, … }`.
- Key delivery is **single-use** (second call → `409`) and requires the checkout
  to be approved and owned by the calling bot. These surface as typed errors
  (`key_fetch_failed_409`, etc.).

## Field mapping: agent-driven first, table as fallback

The driving assistant already sees the page, so **agent-provided selectors are
the primary mapping path** and the profiles table is the fallback:

1. The agent asks what it is mapping — `…-schema` → `{ profile, tokens }` — which
   returns the token **names** the source exposes (e.g. `number`, `cvv`,
   `exp_month`), read from the profile tagged at setup. No decryption, no values.
2. The agent inspects the page and passes a `targets` map (token → CSS selector)
   in the fill request. Explicit selectors **take priority** over everything.
3. Only where the agent gives no selector does the extension fall back to the
   generic detector + the curated profile aliases.

So "use AI to analyze the fields" happens in the agent (over non-secret page
structure and token names); the secret values are still resolved and filled only
inside the extension. Filling all PCI-sensitive fields = requesting the tokens
you need, e.g. `fields: ["number", "cvv"]`, with `targets` for each.

## Field detection & profiles

Detection is descriptor-driven: explicit `selector` → primary token
(autocomplete / name / id / substring) → **curated aliases** (exact matches
only). The aliases come from `profiles.js`, small schema tables that do two safe,
non-fuzzy jobs:

- **canonicalize** a requested name to the record key (e.g. the skill's
  `verification_value` → the record's `cvv`).
- provide **specific** DOM candidates per field (`cc-number`, `address-line1`,
  `current-password`, …) tried as exact attribute matches.

Adding a use case = adding a data entry. Unknown tokens still resolve via the
generic detector.

## Security boundary & honest limitations

- **Strong for cross-origin embedded fields.** Real payment inputs render in
  cross-origin iframes (Stripe, Shopify PCI, Adyen, Braintree). Page JS can't
  read across that origin, so values filled there stay out of the assistant's
  reach. This is the primary case, and the frame-routing (`webNavigation`
  + per-frame `sendMessage`) targets it directly.
- **Weaker for same-origin fields.** If a field is a plain same-origin input,
  page JS can read `input.value` after the fill. The isolated world keeps the
  credential, key, and resolution logic out of the page, but cannot hide a value
  already typed into a same-origin field. Don't treat same-origin fills as
  confidential from the page.
- **A fill needs an approved reference.** A page script can't exfiltrate by
  sending `…-fill` — it has no valid single-use, approval-gated `ref`. It can at
  most send `setup`/`clear`, which are rejected from the page.
- **Memory wipe is best-effort.** Values are overwritten and dropped after fill;
  JS/WebCrypto give no hard zeroization guarantee.

## Files

| File | Purpose |
|---|---|
| `manifest.json` | MV3 manifest. |
| `background.js` | Service worker: key fetch, AES-256-GCM decrypt, frame routing, wipe. |
| `content.js` | All frames: detect/apply; top frame also bridges page ↔ worker (both namespaces). |
| `page-bridge.js` | MAIN world: readiness flag + status-only result property. |
| `lib/field-detect.js` | Descriptor → element (selector, token, aliases). |
| `lib/fill-engine.js` | Writes values + framework-compatible events. |
| `profiles.js` | Schema tables (canonicalize + detection aliases). |
| `setup.html` / `setup.js` | Pairing / status (options page). |
| `test/harness.html` | Offline detection/fill + alias check (no network, no real data). |
| `PRIVACY.md`, `STORE-LISTING.md` | Store submission material. |

## Load / build

Unpacked: `chrome://extensions` → Developer mode → Load unpacked → this folder →
open the options page → enter credential (+ optional source).
To submit: zip the folder contents. See `STORE-LISTING.md`.
