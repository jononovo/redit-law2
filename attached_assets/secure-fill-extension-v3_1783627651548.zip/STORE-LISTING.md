# SecureFill — Chrome Web Store submission notes

Internal checklist for publishing. Not shipped to users. The guiding principle:
**pass review by being accurate, not by hiding what the extension does.**

## Listing copy

- **Name:** SecureFill
- **Summary:** Fill form fields from a referenced source, keeping the values out
  of an assistant's context.
- **Category:** Productivity
- **Single purpose:** "Securely fill form fields from a referenced source." Keep
  it to that one purpose — single-purpose is a review requirement.

The neutral name reflects that the tool is genuinely general-purpose (logins,
addresses, tokens, payment data). This is accurate framing, **not** an attempt to
obscure a data type. Do not write copy whose goal is to keep a reviewer from
noticing a category the extension actually handles.

## Permission justifications (paste into the dashboard)

- **storage** — Persist the connection credential and configuration on the
  user's device between sessions.
- **webNavigation** — Enumerate the active tab's frames so a value can be routed
  to the correct field, including fields rendered inside cross-origin iframes.
- **host permission `https://creditclaw.com/*`** — Fetch the one-time decryption
  key from the user's configured backend.
- **content scripts on `https://*/*`** — Fields can be on any site the user
  visits; the extension must run on the page in use. Same broad-host model
  established password managers use.

## Data-use disclosures — declare truthfully

In the Privacy practices form, check every category the extension actually
handles in your deployment. For the initial (payment) use case that is at least:

- **Authentication information** — if it fills usernames/passwords/tokens.
- **Financial and payment information** — if it fills card details.
- **Personally identifiable information** — if it fills names/addresses/phone.

State that data is used **solely to fill the user's own forms**, is **not sold or
transferred**, and is not used for advertising. Under-declaring to appear
low-risk is a policy violation and risks removal after approval — declare fully.

## Review gates (must hold before submission)

- Manifest V3. ✅
- No remotely-hosted code: all JS bundled; no `eval`, no external script loads.
  The extension fetches **data** only, never code. ✅
- No obfuscation; source is readable. ✅
- Privacy policy published at a public URL and linked. ⛳ host `PRIVACY.md`.
- Data-use disclosures completed truthfully (see above). ⛳
- Icons 16/48/128 present. ✅ (replace the placeholder art before launch ⛳)

## Notes

- Broad `https://*/*` content scripts are used so fills work on arbitrary sites
  without per-site prompts. If you prefer a tighter model, switch to
  `optional_host_permissions` and request per-site — note this needs a user
  gesture per site and breaks unattended automation.
